#include <iostream>
using namespace std;


int main()
{
    string a = "1234567";
    cout << a << endl;
    cout << "a.c_str() = \n" << a.c_str() << endl;
    sprintf("%s",a.c_str());
}